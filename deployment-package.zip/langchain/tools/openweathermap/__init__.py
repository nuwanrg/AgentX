"""OpenWeatherMap API toolkit."""
